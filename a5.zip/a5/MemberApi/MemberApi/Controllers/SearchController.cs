﻿using MemberApi.Data;
using MemberApi.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Practical2.Models;

namespace MemberApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public SearchController(ApplicationDbContext db)
        {
            _db = db;
        }

        //[HttpGet("CategoryN")]
        ////[Route]
        //public async Task<IActionResult> GetCategoryN(string name)
        //{
        //    var cate = (
        //               from t1 in _db.Products
        //               join t2 in _db.Categories
        //               on t1.Category.Name equals t2.Name
        //               where t2.Name == name
        //               group t1.Name by t2.Name into tt
        //               select new { category = tt.Key, product = string.Join(',', tt.ToArray()) }).ToList();
        //    return Ok(cate);

        //}

        //[HttpGet("ProductN")]
        ////[Route]
        //public async Task<IActionResult> GetProductN(string name)
        //{
        //    var cate = (
        //               from t1 in _db.Categories
        //               join t2 in _db.Products
        //               on t1.Name equals t2.Category.Name
        //               where t1.Name == name || t2.Name == name
        //               group t2.Name by t1.Name into tt
        //               select new { category = tt.Key, product = string.Join(',', tt.ToArray()) }).ToList();
        //    return Ok(cate);

        //}
        
        [HttpGet]
        [Route("Product")]
        public async Task<IActionResult> GetProduct(string name)
        {

            if (name != "null")
            {


                var Data = (from t1 in _db.Categories
                            join t2 in _db.Products
                            on t1.Name equals t2.Category.Name
                            where t1.Name == name || t2.Name == name
                            group t2.Name by t1 into temp
                            select new { category = temp.Key, product = string.Join(',', temp.ToArray()) }).ToList();


                ApiClass apidatafilter = new ApiClass();
                if (Data.Count != 0)
                {
                    apidatafilter.status = true;
                    apidatafilter.message = "Success...";
                    apidatafilter.data = Data;

                }
                else
                {
                    apidatafilter.status = false;
                    apidatafilter.message = "Data Not Found";
                    apidatafilter.data = null;
                }

                return Ok(apidatafilter);
            }


            var productdata = _db.Products.ToList();
            ApiClass apidata = new ApiClass();
            if (productdata.Count != 0)
            {
                apidata.status = true;
                apidata.message = "Success...";
                apidata.data = productdata;

            }
            else
            {
                apidata.status = false;
                apidata.message = "Data Not Found";
                apidata.data = null;
            }


            return Ok(apidata);

        }



        [HttpGet]
        [Route("Category")]
        public async Task<IActionResult> GetCategory(string name)
        {

            if (name != "null")
            {

                var productData = (from t1 in _db.Products
                                   join t2 in _db.Categories on t1.Category.Name equals t2.Name
                                   where t1.Name == name || t2.Name == name
                                   group t1.Name by t2 into temp
                                   select new { category = temp.Key, product = temp.ToArray() }).ToList();

                ApiClass apidatafilter = new ApiClass();
                if (productData.Count != 0)
                {
                    apidatafilter.status = true;
                    apidatafilter.message = "Success...";
                    apidatafilter.data = productData;

                }
                else
                {
                    apidatafilter.status = false;
                    apidatafilter.message = "Data Not Found";
                    apidatafilter.data = null;
                }

                return Ok(apidatafilter);
            }

            var productdata = _db.Categories.ToList();
            ApiClass apidata = new ApiClass();
            if (productdata.Count != 0)
            {
                apidata.status = true;
                apidata.message = "Success...";
                apidata.data = productdata;

            }
            else
            {
                apidata.status = false;
                apidata.message = "Data Not Found";
                apidata.data = null;
            }


            return Ok(apidata);



        }
    }
}
    


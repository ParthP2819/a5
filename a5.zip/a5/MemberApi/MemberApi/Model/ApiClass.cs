﻿namespace MemberApi.Model
{
    public class ApiClass
    {
        public bool status { get; set; }
        public string message { get; set; }
        public dynamic data { get; set; }
    }
}

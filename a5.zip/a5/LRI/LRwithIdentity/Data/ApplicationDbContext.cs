﻿using LRwithIdentity.Models;
using Microsoft.EntityFrameworkCore;

namespace LRwithIdentity.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Login> getlogin { get; set; }
    }
}

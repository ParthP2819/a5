﻿using Microsoft.EntityFrameworkCore;
using TestDemoLogin.Models;

namespace TestDemoLogin.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Login> getlogin { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using TestDemoLogin.Data;
using TestDemoLogin.Models;

namespace TestDemoLogin.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly IHttpContextAccessor _ca;
        public LoginController(ApplicationDbContext db, IHttpContextAccessor contextAccessor)
        {
            _db = db;
            _ca = contextAccessor;
        }
        //Get action 
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        //post 
        public IActionResult Index(Login obj)
        {
            var objFromDb = _db.getlogin.Where(login => login.Username == obj.Username && login.Password == obj.Password).FirstOrDefault();
            if (objFromDb != null)
            {
                

                _ca.HttpContext.Session.SetString("Uname",obj.Username.ToString());
                _ca.HttpContext.Session.SetString("Pass", obj.Password.ToString());
                
                TempData["success"] = "Login successfully:)";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View();
            }
        }
       
        //Post
        [HttpPost]
        public IActionResult Logout()
        {
            _ca.HttpContext.Session.Remove("Uname");
            _ca.HttpContext.Session.Remove("Pass");


            return RedirectToAction("Index");
        }

        //get
        public IActionResult Signup() 
        {
            return View("reg");
        }

        //Post
        [HttpPost]
        public IActionResult Signup(Login obj)
        {
            _db.getlogin.Add(obj);
            _db.SaveChanges();
            return RedirectToAction("Index", "Home");
            //_ca.HttpContext.Session.GetString("Uname", obj.Username.ToString());
            //_ca.HttpContext.Session.GetString("Uname", obj.Username.ToString());

        }

    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace Practice_LR.Models
{
    public class RegFormCreate
    {
        
    }
}

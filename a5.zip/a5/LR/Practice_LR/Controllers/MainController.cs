﻿using Microsoft.AspNetCore.Mvc;

namespace Practice_LR.Controllers
{
    public class MainController : Controller
    {
        public IActionResult Main()
        {
            return View();
        }
    }
}

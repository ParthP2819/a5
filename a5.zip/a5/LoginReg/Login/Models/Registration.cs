﻿using System.ComponentModel.DataAnnotations;

namespace Login.Models
{
    public class Registration
    {
        [Key]
        public int Id { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        [Required]
        public string Uname { get; set; }  
        [Required]
        public string Password { get; set; }
    }
}

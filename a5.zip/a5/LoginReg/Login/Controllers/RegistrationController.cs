﻿using Microsoft.AspNetCore.Mvc;

namespace Login.Controllers
{
    public class RegistrationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
